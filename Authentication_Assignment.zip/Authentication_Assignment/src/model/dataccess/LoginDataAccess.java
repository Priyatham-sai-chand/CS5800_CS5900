package model.dataccess;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.connectionfactory.DataBaseConnection;
import model.connectionfactory.connectionFactory;
import model.entities.User;
import org.postgresql.core.ConnectionFactory;

public class LoginDataAccess {
	private LoginDataAccess() {}

	private static LoginDataAccess instance;
	  public static LoginDataAccess getInstance(){
        if( instance == null){
            instance = new LoginDataAccess();
        }
        return instance;
    }
	public static Boolean verifyCredentials(User user) throws ClassNotFoundException, SQLException {

		connectionFactory connectionFactory = new connectionFactory();
		DataBaseConnection dataBaseConnection = connectionFactory.getConnection("postgresql");
		  Connection conection =  dataBaseConnection.getDataBaseConnection();

		final PreparedStatement stmt = conection.prepareStatement("SELECT * FROM users WHERE username=? and password=?");

		stmt.setString(1, user.getUserName());
		stmt.setString(2, user.getPassword());

		ResultSet rs = stmt.executeQuery();

		return rs.next();


	}

}

