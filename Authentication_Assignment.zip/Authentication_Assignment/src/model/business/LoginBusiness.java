package model.business;

import model.dataccess.LoginDataAccess;
import java.sql.SQLException;
import model.entities.MessageException;
import model.entities.User;

public class LoginBusiness  {
    private static LoginBusiness instance;
    private  String userName = "";
    private  String password = "";
    private LoginBusiness(){
    }
    private String getUserName(){
        return userName;
    }
    private String getPassword(){
        return password;
    }
    private void setPassword(String password){
        this.password = password;
    }
    private void setUserName(String userName){
        this.userName = userName;
    }
    public static LoginBusiness getInstance(){
        if( instance == null){
            instance = new LoginBusiness();
        }
        return instance;
    }
   public static boolean verifyCredentials(String userName, String password) throws SQLException, ClassNotFoundException {

          if (userName.equals("")) {
                throw new MessageException("Username not informed.");
            } else if (password.equals("")) {
                throw new MessageException("Password not informed.");
            }
            User user = User.getInstance(userName, password);

            return LoginDataAccess.verifyCredentials(user);
   }
}
