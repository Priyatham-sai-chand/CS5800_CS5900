package model.connectionfactory;


public class connectionFactory {
   public connectionFactory(){};
   public DataBaseConnection getConnection(String dataBase){

      if(dataBase == null) return null;

      else if (dataBase.equalsIgnoreCase("POSTGRESQL")){
         return new PostgresConnection();
      }
      else if (dataBase.equalsIgnoreCase("MYSQL")){
         return new MySqlConnection();
      }
     return null;
   }
}
