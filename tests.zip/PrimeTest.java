import org.junit.Test;
import org.junit.Assert.*;

import static org.junit.Assert.*;

public class PrimeTest {
    @Test
    public void test_2() {
        Prime p = new Prime();
        Boolean ans = p.isPrime(2);
        assertEquals(true,ans);
    }
    @Test
    public void test_3() {
        Prime p = new Prime();
        Boolean ans = p.isPrime(3);
        assertEquals(true,ans);
    }
    @Test
    public void test_4() {
        Prime p = new Prime();
        boolean ans = p.isPrime(4);
        assertFalse(ans);
    }
    @Test
    public void test_5() {
        Prime p = new Prime();
        boolean ans = p.isPrime(5);
        assertTrue(ans);
    }
    @Test
    public void test_6() {
        Prime p = new Prime();
        boolean ans = p.isPrime(6);
        assertFalse(ans);
    }
}
